library(dplyr)
library(Momocs)

# Define the image source folder
image.folder <- "~/Downloads/multiple_image_import_test/"
(image.files <- list.files(image.folder))

# Load shapes from the images as `Opn`, open outline data objects
shapes <- import_jpg(paste0(image.folder,image.files)) %>% Opn()

# Preview the raw shapes
shapes %>% panel()
shapes %>% stack()

# check the shape with the smallest number of landmarks
min.landmarks <- lapply(shapes$coo, dim) %>% 
  as.data.frame() %>% 
  dplyr::slice_head(n=1) %>% 
  min()
min.landmarks

# Down-sample the landmarks so all shapes have the same number
# This is necessary since importing images of different sizes results 
# in outlines with different numbers of points (landmarks)
shapes <- shapes %>% 
  coo_sample(min.landmarks)

# Everything should work as described in the tutorial from here!


# GPA
gpa.shapes <- shapes %>% 
  fgProcrustes() %T>%
  stack()

# Examine harmonic power
gpa.shapes$coo[[1]] %>% 
  efourier(nb.h = 25) %>% 
  harm_pow() %>% 
  cumsum() %T>% 
  plot(
    type='o',
    xlab='Harmonic rank',
    ylab='Cumulated harmonic power'
  ) %>%
  median() %>% 
  abline(h=., col = "darkred")

